package day01;

import java.util.Scanner;

public class N18 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String num1 = sc.nextLine();
		System.out.println(num1);
		String num2 = sc.nextLine();
		System.out.println(num2);
		
//		int result = num1+num2;
		System.out.printf("안녕하세요 %s, %s살이군요", num1,num2);
	}
}
