
package day01;

public class N4 {
public static void main(String[] args) {
	System.out.printf();
	System.out.print();
}
}
