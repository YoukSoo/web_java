package day01;

import java.util.Scanner;

public class N14 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	
		String str1 = sc.next();
		System.out.println(str1);
		
		String str2 = sc.next();
		System.out.println(Integer.parseInt(str2));
		
		String str3 = sc.next();
		System.out.println(Double.parseDouble(str3));
		
		
		
		
	
		
	}
}
