//인트 
package day01;

public class N2 {

}
