package day01;

import java.util.Scanner;

public class N17 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int num1 = sc.nextInt();
		System.out.println(num1);
		int num2 = sc.nextInt();
		System.out.println(num2);
		
		int result = num1+num2;
		System.out.println(result);
	}
}
