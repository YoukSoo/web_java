//운영체제의 구해받지 않고 JVM과 컴파일러를 통해 작동한다 

package day01;

public class N6 {

}
