// data++,++data,--data,data--
package day01;

public class N8 {

}
