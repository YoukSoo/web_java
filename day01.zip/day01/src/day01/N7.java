//
package day01;

public class N7 {
	public static void main(String[] args) {
		String str = "315";
		int str2 = Integer.parseInt(str);
		System.out.println(str2+1);
	}
}
