// 전위형과 후위형 - --data,data--, 전위형은 바로 후위형은 나중에
package day01;

public class N9 {

}
