package day01;

import java.util.Scanner;

public class N16 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		double num1 = sc.nextDouble();
		System.out.println(num1);
		double num2 = sc.nextDouble();
		System.out.println(num2);
		
		double result = num1/num2;
		System.out.println(result);
	}
}
