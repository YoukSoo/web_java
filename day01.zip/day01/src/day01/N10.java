// sc.nextLine();
package day01;

public class N10 {

}
