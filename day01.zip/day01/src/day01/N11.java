// 프로그램이 직접 운영체제와 얘기를 안함, JVM사용
package day01;

public class N11 {

}
