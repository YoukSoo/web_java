package day01;

public class N5 {
public static void main(String[] args) {
	//3
	
}
}
