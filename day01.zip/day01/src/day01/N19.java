package day01;

import java.util.Scanner;

public class N19 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		double r = sc.nextDouble();
	    double result = r * r *3.14;
	    		System.out.println(result);
	}
}
