// 다른 자료형에 넣고싶을때 자동이든 강제든 해서 넣는것
package day01;

public class N12 {

}
