//2번

package day01;

public class N1 {

}
