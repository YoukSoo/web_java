//넥스트 인트는 인트값으로 입력받고 넥스트는 스트링으로 받는다
package day01;

public class N13 {

}
